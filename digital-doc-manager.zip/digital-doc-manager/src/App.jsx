import UploadForm from "./components/UploadForm";
import DocumentList from "./components/DocumentList";
import { Container, Typography, Box } from "@mui/material";

function App() {
  return (
    <Container maxWidth="lg">
      <Box sx={{ textAlign: "center", my: 4 }}>
        <Typography variant="h3" fontWeight="600">
           Digital Document Manager
        </Typography>
        <Typography variant="subtitle1" sx={{ opacity: 0.7 }}>
          Manage your files smartly & securely
        </Typography>
      </Box>

      <UploadForm />
      <DocumentList />
    </Container>
  );
}

export default App;