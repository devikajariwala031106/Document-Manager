import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { db } from "../../firebase/firebase";
import { ref, push, onValue, remove } from "firebase/database";

// Upload
export const uploadDocument = createAsyncThunk(
    "documents/upload",
    async (doc) => {
        const docRef = ref(db, "documents");
        await push(docRef, doc);
    }
);

// Fetch
export const fetchDocuments = createAsyncThunk(
    "documents/fetch",
    async (_, { dispatch }) => {
        const docRef = ref(db, "documents");
        onValue(docRef, (snapshot) => {
            const data = snapshot.val() || {};
            const docs = Object.keys(data).map((key) => ({
                id: key,
                ...data[key]
            }));
            dispatch(setDocuments(docs));
        });
    }
);

// Delete
export const deleteDocument = createAsyncThunk(
    "documents/delete",
    async (id) => {
        await remove(ref(db, `documents/${id}`));
    }
);

const documentSlice = createSlice({
    name: "documents",
    initialState: {
        list: []
    },
    reducers: {
        setDocuments: (state, action) => {
            state.list = action.payload;
        }
    }
});

export const { setDocuments } = documentSlice.actions;
export default documentSlice.reducer;