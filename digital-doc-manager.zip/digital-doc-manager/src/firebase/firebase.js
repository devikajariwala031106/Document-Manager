import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
    apiKey: "AIzaSyB83H8EPhczvRsRbVqdNoKunNHLokNpBsU",
    authDomain: "digital-doc-manager-77e0e.firebaseapp.com",
    databaseURL: "https://digital-doc-manager-77e0e-default-rtdb.firebaseio.com/",
    projectId: "digital-doc-manager-77e0e",
    storageBucket: "digital-doc-manager-77e0e.firebasestorage.app",
    messagingSenderId: "800723003576",
    appId: "1:800723003576:web:b75a45b84104568a736c4d",
    measurementId: "G-64XVSC0ETS"
};

const app = initializeApp(firebaseConfig);

export const db = getDatabase(app);