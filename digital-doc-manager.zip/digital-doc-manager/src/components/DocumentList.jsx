import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchDocuments } from "../features/documents/documentSlice";
import DocumentCard from "./DocumentCard";
import { Grid } from "@mui/material";

export default function DocumentList() {
  const dispatch = useDispatch();
  const docs = useSelector((state) => state.documents.list);

  useEffect(() => {
    dispatch(fetchDocuments());
  }, []);

  return (
    <Grid container spacing={3}>
      {docs.map((doc) => (
        <Grid item xs={12} sm={6} md={4} key={doc.id}>
          <DocumentCard doc={doc} />
        </Grid>
      ))}
    </Grid>
  );
}