import { useState } from "react";
import { useDispatch } from "react-redux";
import { uploadDocument } from "../features/documents/documentSlice";
import { Box, Button, Typography } from "@mui/material";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";

export default function UploadForm() {
  const [file, setFile] = useState(null);
  const dispatch = useDispatch();

  const convertBase64 = (file) =>
    new Promise((res, rej) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => res(reader.result);
      reader.onerror = rej;
    });

  const handleUpload = async () => {
    if (!file) return;
    const base64 = await convertBase64(file);

    dispatch(
      uploadDocument({
        name: file.name,
        type: file.type,
        data: base64,
        date: new Date().toLocaleString()
      })
    );
  };

  return (
    <Box
      sx={{
        p: 4,
        borderRadius: 4,
        backdropFilter: "blur(10px)",
        background: "rgba(255,255,255,0.05)",
        boxShadow: "0 8px 32px rgba(0,0,0,0.3)",
        textAlign: "center",
        mb: 4
      }}
    >
      <Typography variant="h6" mb={2}>
        Upload Your Document
      </Typography>

      <input
        type="file"
        onChange={(e) => setFile(e.target.files[0])}
        style={{ marginBottom: "10px" }}
      />

      <br />

      <Button
        variant="contained"
        startIcon={<CloudUploadIcon />}
        onClick={handleUpload}
        sx={{
          mt: 2,
          borderRadius: "20px",
          px: 4
        }}
      >
        Upload File
      </Button>
    </Box>
  );
}