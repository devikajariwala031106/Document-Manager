import {
  Card,
  CardContent,
  Typography,
  Button,
  Stack
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import DownloadIcon from "@mui/icons-material/Download";
import { useDispatch } from "react-redux";
import { deleteDocument } from "../features/documents/documentSlice";

export default function DocumentCard({ doc }) {
  const dispatch = useDispatch();

  const downloadFile = () => {
    const link = document.createElement("a");
    link.href = doc.data;
    link.download = doc.name;
    link.click();
  };

  return (
    <Card
      sx={{
        borderRadius: 4,
        backdropFilter: "blur(10px)",
        background: "rgba(255,255,255,0.05)",
        boxShadow: "0 8px 20px rgba(0,0,0,0.3)",
        transition: "0.3s",
        "&:hover": { transform: "scale(1.03)" }
      }}
    >
      <CardContent>
        <Typography fontWeight="600">{doc.name}</Typography>
        <Typography variant="body2" sx={{ opacity: 0.7 }}>
          {doc.type}
        </Typography>
        <Typography variant="caption" sx={{ opacity: 0.5 }}>
          {doc.date}
        </Typography>

        <Stack direction="row" spacing={1} mt={2}>
          <Button
            size="small"
            startIcon={<DownloadIcon />}
            onClick={downloadFile}
          >
            Download
          </Button>

          <Button
            size="small"
            color="error"
            startIcon={<DeleteIcon />}
            onClick={() => dispatch(deleteDocument(doc.id))}
          >
            Delete
          </Button>
        </Stack>
      </CardContent>
    </Card>
  );
}